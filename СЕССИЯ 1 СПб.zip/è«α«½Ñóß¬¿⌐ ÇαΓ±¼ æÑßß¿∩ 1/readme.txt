Для корректной работы Report.ipynb необходимо установить следуюцие зависимости ():
1. pymystem3 (нет в стандартном пакете anaconda)
-pip install pymystem3
2. nltk 
-pip install nltk
3. sklearn
-pip install scikit-learn

Отчеты представлены в файлах: Report.html и Report.ipynb
Обработаные данные в Data.zip